from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MaxLengthValidator, MinValueValidator
from django.db.models.deletion import CASCADE


# Create your models here.

STATE_CHOICES = (
    ('Andaman & Nicobar Islands' , 'Andaman & Nicobar Islands'),
    ('Arunachal Pradesh (AR)' , 'Arunachal Pradesh (AR)'),
    ('Assam (AS)' , 'Assam (AS)'),
    ('Bihar (BR)' , 'Bihar (BR)'),
    ('Chhattisgarh (CG)' , 'Chhattisgarh (CG)'),
    ('Goa (GA)' , 'Goa (GA)'),
    ('Gujarat (GJ)' , 'Gujarat (GJ)'),
    ('Haryana (HR)' , 'Haryana (HR)'),
    ('Himachal Pradesh (HP)' , 'Himachal Pradesh (HP)'),
    ('Jammu and Kashmir (JK)' , 'Jammu and Kashmir (JK)'),
    ('Jharkhand (JH)' , 'Jharkhand (JH)'),
    ('Karnataka (KA)' , 'Karnataka (KA)'),
    ('Kerala (KL)' , 'Kerala (KL)'),
    ('Madhya Pradesh (MP)' , 'Madhya Pradesh (MP)'),
    ('Maharashtra (MH)' , 'Maharashtra (MH)'),
    ('Manipur (MN)' , 'Manipur (MN)'),
    ('Meghalaya (ML)' , 'Meghalaya (ML)'),
    ('Mizoram (MZ)' , 'Mizoram (MZ)'),
    ('Nagaland (NL)' , 'Nagaland (NL)'),
    ('Odisha(OR)' , 'Odisha(OR)'),
    ('Punjab (PB)' , 'Punjab (PB)'),
    ('Rajasthan (RJ)' , 'Rajasthan (RJ)'),
    ('Sikkim (SK)' , 'Sikkim (SK)'),
    ('Tamil Nadu (TN)' , 'Tamil Nadu (TN)'),
    ('Telangana (TS)' , 'Telangana (TS)'),
    ('Tripura (TR)' , 'Tripura (TR)'),
    ('Uttar Pradesh (UP)' , 'Uttar Pradesh (UP)'),
    ('Uttarakhand (UK)' , 'Uttarakhand (UK)'),
    ('West Bengal (WB))' , 'West Bengal (WB))'),

)

class Customer(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    locality = models.CharField(max_length=200)
    city = models.CharField(max_length=50)
    zipcode = models.IntegerField()
    state = models.CharField(choices=STATE_CHOICES,max_length=50)

    def __str__(self) :
        return str(self.id)

CATEGORY_CHOICES = (
        ('M','Mobile'),
        ('L','Laptop'),
        ('TW','Top Wear'),
        ('BW','Bottom Wear'),
)

class Product(models.Model):
    title = models.CharField(max_length=100)
    selling_price = models.FloatField()
    discount_price = models.FloatField()
    description = models.TextField()
    brand = models.CharField(max_length=100)
    category = models.CharField(choices=CATEGORY_CHOICES,max_length=2)
    product_image = models.ImageField(upload_to='productimg')

    def __str__(self) :
        return str(self.id)


class Cart(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    product = models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self) :
        return str(self.id)

    @property
    def total_cost(self):
        return self.quantity * self.product.discount_price

STATUS_CHOICES = (
    ('Accepted','Accepted'),
    ('Packed','Packed'),
    ('On The Way','On The Way'),
    ('Delivered','Delivered'),
    ('Cancel','Cancel'),
)

class OrderPlaced(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer,on_delete=models.CASCADE)
    product = models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    order_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=50,choices=STATUS_CHOICES,default='Pending')

    @property
    def total_cost(self):
        return self.quantity * self.product.discount_price