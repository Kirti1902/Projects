from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name="home"),
    #notes section--
    path('notes.html',views.notes,name="notes"),
    path('delete_note/<int:pk>',views.delete_note,name="delete-note"),
    path('notes_detail/<int:pk>',views.NotesDetailView.as_view(),name="notes-detail"),

    #homework section--
    path('homework.html',views.homework,name="homework"),
    path('update_homework/<int:pk>',views.update_homework,name="update-homework"),
    path('delete_homework/<int:pk>',views.delete_homework,name="delete-homework"),

    #youtbe section--
    path('youtube.html',views.youtube,name="youtube"),

    #todo section--
    path('todo.html',views.todo,name="todo"),
    path('update_todo/<int:pk>',views.update_todo,name="update-todo"),
    path('delete_todo/<int:pk>',views.delete_todo,name="delete-todo"),

    #books section--
    path('books.html',views.books,name="books"),

    #dictionary section--
    path('dictionary.html',views.dictionary,name="dictionary"),

    #wikipedia section--
    path('wiki.html',views.wiki,name="wiki"),

    #conversion section--
    path('conversion.html',views.conversion,name="conversion"),

]
