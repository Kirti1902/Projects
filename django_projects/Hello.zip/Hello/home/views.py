from django.http.response import HttpResponseRedirect
from django.shortcuts import render , HttpResponse
from datetime import datetime
from home.models import Contact, Order
from django.contrib import messages
from django.contrib.auth.models import User

# Create your views here.

def index(request):
    #context={ 
    #    'variable1':"this is sent",
    #    'variable2':"this is sent again"
    #}
    messages.success(request,"Welcome to Ice-Cream Factory!")
    return render(request,'index.html')
    #return HttpResponse("this is the homepage")

def about(request):
    messages.success(request,"Welcome to About Section.!")
    return render(request,'about.html')
    #return HttpResponse("this is the about page")

def services(request):
    messages.success(request,"Welcome to Our Gallery.!")
    return render(request,'services.html')
    #return HttpResponse("this is the services page")

def falvours(request):
    #messages.success(request,"Welcome to the wide range of Flavours!")
    return render(request,'falvours.html')  

def order(request):
    messages.success(request,"Order your favorite ice-creams now!!")
    
    if request.method =="POST":
        name=request.POST.get('name')
        mobile=request.POST.get('mobile')
        adress=request.POST.get('adress')
        order =Order(name=name,mobile=mobile,adress=adress,date=datetime.today())
        order.save()
        messages.success(request, 'Your order has been recorded.')
    return render(request,'order.html')
   

def contact(request):
    messages.success(request,"Welcome to Contact Section.!")
    if request.method =="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        desc=request.POST.get('desc')
        contact =Contact(name=name,email=email,phone=phone,desc=desc,date=datetime.today())
        contact.save()
        messages.success(request, 'Your message has been sent.')
    return render(request,'contact.html')
    #return HttpResponse("this is the contact page")