package com.scaler.blogapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogappSpringbootApplicationTests {

    @Test
    void contextLoads() {
    }

}
