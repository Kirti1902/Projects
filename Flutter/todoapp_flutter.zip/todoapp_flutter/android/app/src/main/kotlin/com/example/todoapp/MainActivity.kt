package com.example.todoapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
