package helper

func GenerateAllTokens(){

}

func updateAllTokens(){

}

func ValidateToken(){
	
}