<!DOCTYPE html>
<html lang="en">
<title>Booking</title>
<head>
    <style>
         body{
        background-color: #596b7e;
        background-image:url("https://www.imv-imaging.co.uk/media/5762/booking-successful.png");
        background-size: cover;
    }
    </style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data</title>
 <script>
     var r = window.location.search;
     alert(r);
 </script>
</head>
<body>
    
</body>
</html>