const btn =document.getElementById('btn');
const result = document.getElementById('result');

var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();


recognition.onstart = function(){
    console.log("Listening your commands......");
    
    recognition.onresult =function(event){
        handleResults(event);
    };

}


function handleResults(event){
    var text = event.results[0][0].transcript;
    text = text.toLowerCase();
    console.log(text);
    document.getElementById('result').innerHTML = text;
    if(text.includes('youtube')){
        
        console.log("Opening Youtube");
        window.open("https://www.youtube.com");
    }else if(text.includes('google')){
        
        console.log("Opening Google");
        window.open("https://www.google.com");
    }else if(text.includes('yahoo')){
        
        console.log("Opening Yahoo");
        window.open("https://www.yahoo.com");
    }else if(text.includes('Gaana')){
        
        console.log("Opening Gaana");
        window.open("https://www.gaana.com");
    }else if(text.includes('favourite song')){
        
        console.log("Playing Music");
        window.open("https://gaana.com/song/teri-khair-mangdi-2");
    }else if(text.includes('radio')){
        
        console.log("Opening Radio");
        window.open("https://gaana.com/radio");
    }else if(text.includes("genda")){
        
        console.log("Opening youtube");
        window.open("https://www.youtube.com/watch?v=SD4Z8dlZPd8");
        
    }else if(text.includes('dad party song')){
        window.open("https://www.youtube.com/watch?v=leyEatUq00E");
    }else if(text.includes('old playlist')){
        window.open("https://www.youtube.com/watch?v=lslZptXok8o&list=PL92D6833E06037526");
    }else if(text.includes('kuwait news')){
        window.open("https://www.kuna.net.kw/Default.aspx?language=en");
    }else if(text.includes('india news')){
        window.open("https://www.hindustantimes.com/india-news/");
    }else if(text.includes('gmail')){
        window.open("https://mail.google.com/mail/u/0/#inbox");
    }else if(text.includes('classroom')){
        window.open("https://classroom.google.com/h");
    }else if(text.includes('gooogle meet')){
        window.open("https://meet.google.com/#");
    }else if(text.includes('close')){
        window.close("file:///C:/Users/HP/Desktop/Computer%20Language%20Folders/javascript%20data/zoro/Voice.html");
    }

    read(text);
}


function read(text){
    var speech = new SpeechSynthesisUtterance;
    
    speech.text = text;
    
    if(text.includes('time'))
        speech.text = 'It is ' + new Date().getHours() + " " + new Date().getMinutes() + " right now";
    else if(text.includes('my birthday'))
        speech.text ="You are not that famous still now to ask people rember your birthday";
        
 
    
    
    window.speechSynthesis.speak(speech);

}


1 