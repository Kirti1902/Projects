import IssueFormSkeleton from "../../_components/IssueFormSkeleton";
export default IssueFormSkeleton;