<template>
    <Header />
    <h1>Hello User, Add Restaurant Page</h1>
    <form class="add">
        <input type="text" v-model="restaurant.name" placeholder="Enter Name" />
        <input type="text" v-model="restaurant.address" placeholder="Enter address" />
        <input type="text" v-model="restaurant.contact" placeholder="Enter contact" />
        <button v-on:click="addRestaurant">Add new Restaurant</button>
    </form>
</template>

<script>
import Header from './Header.vue';
import axios from 'axios';

export default {
    name: 'Add',
    components: {
        Header
    },
    data() {
        return {
            restaurant: {
                name: '',
                address: '',
                contact: ''
            }
        }

    },
    methods: {
        async addRestaurant() 
        {
            const result = await axios.post("http://localhost:3000/restaurant", {
                name: this.restaurant.name,
                address: this.restaurant.address,
                contact: this.restaurant.contact,

            });
            if (result.status === 201) { // Corrected typo here
                this.$router.push({ name: 'Home' });
            }
        }
    },
    mounted() 
    {
        let user = localStorage.getItem('user-info');
        if (!user) {
            this.$router.push({ name: 'SignUp' })
        }
    }
}
</script>